src.core.exceptions
===================

.. currentmodule:: src.core.exceptions

.. automodule:: src.core.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

Module Contents
--------------

.. autoclass:: ConfigurationError
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: ModelError
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: ProcessingError
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: StorageError
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: ValidationError
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: VideoUnderstandingError
   :members:
   :undoc-members:
   :show-inheritance:
