src.ai.pipeline.VideoConfig
===========================

.. currentmodule:: src.ai.pipeline

.. autoclass:: VideoConfig
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoConfig.__init__
      ~VideoConfig.validate
   
   

   
   
   