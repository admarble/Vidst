src.storage.vector.VectorStorage
================================

.. currentmodule:: src.storage.vector

.. autoclass:: VectorStorage
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VectorStorage.__init__
      ~VectorStorage.get_metadata
      ~VectorStorage.retrieve
      ~VectorStorage.search
      ~VectorStorage.store
   
   

   
   
   