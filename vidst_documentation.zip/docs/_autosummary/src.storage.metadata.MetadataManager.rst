src.storage.metadata.MetadataManager
====================================

.. currentmodule:: src.storage.metadata

.. autoclass:: MetadataManager
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~MetadataManager.__init__
      ~MetadataManager.retrieve
      ~MetadataManager.store
      ~MetadataManager.update
   
   

   
   
   