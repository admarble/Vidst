src.ai.models.gpt4v
===================

.. automodule:: src.ai.models.gpt4v

   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Any
      BaseModel
      GPT4VisionModel
      Path
   
   

   
   
   .. rubric:: Exceptions

   .. autosummary::
   
      ModelError
   
   



