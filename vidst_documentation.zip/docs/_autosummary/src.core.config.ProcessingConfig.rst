src.core.config.ProcessingConfig
================================

.. currentmodule:: src.core.config

.. autoclass:: ProcessingConfig
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~ProcessingConfig.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~ProcessingConfig.max_concurrent_jobs
      ~ProcessingConfig.memory_limit_per_job
   
   