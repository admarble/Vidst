src.storage.vector.StorageError
===============================

.. currentmodule:: src.storage.vector

.. autoexception:: StorageError