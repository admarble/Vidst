src.core.test\_doc.helper\_function
===================================

.. currentmodule:: src.core.test_doc

.. autofunction:: helper_function