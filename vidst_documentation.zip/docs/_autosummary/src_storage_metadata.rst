src.storage.metadata
====================

.. currentmodule:: src.storage.metadata

.. automodule:: src.storage.metadata
   :members:
   :undoc-members:
   :show-inheritance:

Module Contents
--------------

.. autoclass:: MetadataManager
   :members:
   :undoc-members:
   :show-inheritance:
