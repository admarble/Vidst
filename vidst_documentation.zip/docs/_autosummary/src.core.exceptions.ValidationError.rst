src.core.exceptions.ValidationError
===================================

.. currentmodule:: src.core.exceptions

.. autoexception:: ValidationError