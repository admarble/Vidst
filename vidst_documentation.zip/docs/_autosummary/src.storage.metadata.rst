﻿src.storage.metadata
====================

.. automodule:: src.storage.metadata
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

    
    
    

    
    
    

    
    
    

    
    
    Classes
           

    .. autosummary::
       :toctree:
       :template: class.rst
    
       Any
       MetadataManager
       Path
    
    

    
    
    