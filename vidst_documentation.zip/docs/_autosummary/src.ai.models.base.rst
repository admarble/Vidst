src.ai.models.base
==================

.. automodule:: src.ai.models.base

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      abstractmethod
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      ABC
      Any
      BaseModel
      TypeVar
   
   

   
   
   .. rubric:: Exceptions

   .. autosummary::
   
      ModelError
   
   



