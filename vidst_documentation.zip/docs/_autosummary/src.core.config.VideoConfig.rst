src.core.config.VideoConfig
===========================

.. currentmodule:: src.core.config

.. autoclass:: VideoConfig
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoConfig.__init__
      ~VideoConfig.validate
   
   

   
   
   