src.core.config.dataclass
=========================

.. currentmodule:: src.core.config

.. autofunction:: dataclass