src.ai.pipeline.VideoPipeline
=============================

.. currentmodule:: src.ai.pipeline

.. autoclass:: VideoPipeline
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoPipeline.__init__
      ~VideoPipeline.add_model
      ~VideoPipeline.detect_scenes
      ~VideoPipeline.extract_text
      ~VideoPipeline.get_memory_usage
      ~VideoPipeline.process
      ~VideoPipeline.transcribe_audio
   
   

   
   
   