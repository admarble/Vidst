src.storage.metadata.Any
========================

.. currentmodule:: src.storage.metadata

.. autoclass:: Any
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Any.__init__
   
   

   
   
   