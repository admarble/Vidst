src.ai.pipeline.ProcessingError
===============================

.. currentmodule:: src.ai.pipeline

.. autoexception:: ProcessingError