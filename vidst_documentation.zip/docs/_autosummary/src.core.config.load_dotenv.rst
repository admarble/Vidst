src.core.config.load\_dotenv
============================

.. currentmodule:: src.core.config

.. autofunction:: load_dotenv