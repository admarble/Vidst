src.core.exceptions.ProcessingError
===================================

.. currentmodule:: src.core.exceptions

.. autoexception:: ProcessingError