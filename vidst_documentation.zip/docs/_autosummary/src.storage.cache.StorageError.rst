src.storage.cache.StorageError
==============================

.. currentmodule:: src.storage.cache

.. autoexception:: StorageError