src.core.exceptions.StorageError
================================

.. currentmodule:: src.core.exceptions

.. autoexception:: StorageError