src.core.input
==============

.. currentmodule:: src.core.input

.. automodule:: src.core.input
   :members:
   :undoc-members:
   :show-inheritance:

Module Contents
--------------

.. autoclass:: VideoInput
   :members:
   :undoc-members:
   :show-inheritance:
