src.storage.cache.Cache
=======================

.. currentmodule:: src.storage.cache

.. autoclass:: Cache
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Cache.__init__
      ~Cache.cleanup
      ~Cache.clear
      ~Cache.get
      ~Cache.set
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Cache.lock
   
   