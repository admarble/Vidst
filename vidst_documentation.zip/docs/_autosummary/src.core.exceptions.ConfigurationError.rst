src.core.exceptions.ConfigurationError
======================================

.. currentmodule:: src.core.exceptions

.. autoexception:: ConfigurationError