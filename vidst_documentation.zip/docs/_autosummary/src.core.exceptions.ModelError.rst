src.core.exceptions.ModelError
==============================

.. currentmodule:: src.core.exceptions

.. autoexception:: ModelError