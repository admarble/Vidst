src.core.input.VideoInput
=========================

.. currentmodule:: src.core.input

.. autoclass:: VideoInput
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoInput.__init__
      ~VideoInput.preprocess
      ~VideoInput.validate
   
   

   
   
   