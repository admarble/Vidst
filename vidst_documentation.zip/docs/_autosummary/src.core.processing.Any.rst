src.core.processing.Any
=======================

.. currentmodule:: src.core.processing

.. autoclass:: Any
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~Any.__init__
   
   

   
   
   