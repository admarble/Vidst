src.core.processing.VideoProcessor
==================================

.. currentmodule:: src.core.processing

.. autoclass:: VideoProcessor
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoProcessor.__init__
      ~VideoProcessor.analyze_scene
      ~VideoProcessor.process
   
   

   
   
   