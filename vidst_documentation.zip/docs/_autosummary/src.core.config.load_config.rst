src.core.config.load\_config
============================

.. currentmodule:: src.core.config

.. autofunction:: load_config