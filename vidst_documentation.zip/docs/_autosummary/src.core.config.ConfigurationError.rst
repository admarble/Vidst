src.core.config.ConfigurationError
==================================

.. currentmodule:: src.core.config

.. autoexception:: ConfigurationError