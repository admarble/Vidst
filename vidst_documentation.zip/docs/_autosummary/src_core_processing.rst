src.core.processing
===================

.. currentmodule:: src.core.processing

.. automodule:: src.core.processing
   :members:
   :undoc-members:
   :show-inheritance:

Module Contents
--------------

.. autoclass:: VideoProcessor
   :members:
   :undoc-members:
   :show-inheritance:
