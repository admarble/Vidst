src.ai.pipeline.BaseModel
=========================

.. currentmodule:: src.ai.pipeline

.. autoclass:: BaseModel
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~BaseModel.__init__
      ~BaseModel.process
      ~BaseModel.process_with_cleanup
      ~BaseModel.retry_with_backoff
      ~BaseModel.validate
      ~BaseModel.validate_input
   
   

   
   
   