﻿src.core.exceptions
===================

.. automodule:: src.core.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
    :special-members: __init__

    
    
    

    
    
    

    
    
    

    
    
    

    
    
    Exceptions
              

    .. autosummary::
       :toctree:
    
       ConfigurationError
       ModelError
       ProcessingError
       StorageError
       ValidationError
       VideoUnderstandingError
    
    