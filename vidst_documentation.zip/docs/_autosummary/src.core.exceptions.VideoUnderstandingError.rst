src.core.exceptions.VideoUnderstandingError
===========================================

.. currentmodule:: src.core.exceptions

.. autoexception:: VideoUnderstandingError