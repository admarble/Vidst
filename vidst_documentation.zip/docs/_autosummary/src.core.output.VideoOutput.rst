src.core.output.VideoOutput
===========================

.. currentmodule:: src.core.output

.. autoclass:: VideoOutput
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~VideoOutput.__init__
      ~VideoOutput.format_results
      ~VideoOutput.save_results
   
   

   
   
   