src.core.test\_doc.TestProcessor
================================

.. currentmodule:: src.core.test_doc

.. autoclass:: TestProcessor
   :members:
   :show-inheritance:
   :special-members: __init__
   :inherited-members:

   
   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
   
      ~TestProcessor.__init__
      ~TestProcessor.process_data
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~TestProcessor.status
   
   