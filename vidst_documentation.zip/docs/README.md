# Documentation

This directory contains project documentation.

## Structure

- `api/` - API documentation
  - `pipeline.md` - AI Pipeline Documentation and Usage
  - `config.md` - Configuration System Documentation
  - `vector_storage.md` - Vector Storage and Similarity Search
  - `error_handling.md` - Error Handling and Recovery
  - `cache.md` - Two-Level Cache System
  - `video_upload.md` - Video Upload and Validation
- `guides/` - User guides and tutorials
- `development/` - Development documentation
- `ci-cd.md` - CI/CD Pipeline Documentation
- `testing-guide.md` - Comprehensive Testing Guide

## Documentation Tools

We provide multiple documentation tools to make documentation maintenance easier:

### 1. Sphinx Documentation

Sphinx generates comprehensive API documentation from docstrings:

```bash
# Install dependencies
pip install -r requirements.txt

# Build HTML documentation
cd docs
make html
```

Features:
- Automatic API documentation generation
- Google-style docstring support
- Type hints integration
- Cross-referencing between documents
- PDF and ePub export options

### 2. MkDocs with Material Theme

MkDocs provides a modern, searchable documentation website:

```bash
# Install dependencies
pip install -r requirements.txt

# Serve documentation locally
mkdocs serve

# Build documentation
mkdocs build
```

Features:
- Modern, responsive design
- Dark/light mode
- Full-text search
- Mermaid diagram support
- Code syntax highlighting
- Automatic versioning

### 3. PDocs for Quick API Documentation

For quick API documentation generation:

```bash
# Generate documentation
pdoc src/ -o docs/api/

# Serve documentation
pdoc src/ --http localhost:8080
```

## Documentation Standards

### 1. Docstring Format

Use Google-style docstrings:

```python
def process_video(file_path: str, options: Dict[str, Any] = None) -> Dict[str, Any]:
    """Process a video file with the given options.

    Args:
        file_path: Path to the video file.
        options: Optional processing parameters.

    Returns:
        Dict containing processing results.

    Raises:
        FileValidationError: If file validation fails.
        ProcessingError: If processing fails.
    """
```

### 2. Documentation Types

1. **Development Documentation**
   - Testing Guide
   - Test Structure and Organization
   - Test Types and Categories
   - Coverage Requirements
   - Best Practices and Patterns
   - CI/CD Pipeline Setup and Usage
   - Code Style Guide
   - API Reference

2. **User Documentation**
   - Installation Guide
   - Configuration Guide
   - Usage Examples
   - Troubleshooting

### 3. Markdown Guidelines

- Use headers for organization
- Include code examples
- Add diagrams using Mermaid
- Keep documentation up to date
- Include version information

## Testing and Coverage

[![Coverage](../coverage.svg)](./testing.md)

Our project maintains high code quality standards with:
- Minimum 85% code coverage requirement
- Automated coverage reporting in PRs
- Comprehensive unit and integration tests
- Detailed coverage documentation in [\1](\2.rst)

## Contributing to Documentation

1. **Adding New Documentation**:
   ```bash
   # Create new documentation file
   touch docs/api/new_feature.md
   
   # Update mkdocs.yml navigation
   # Update relevant index files
   ```

2. **Updating Existing Documentation**:
   - Keep API documentation in sync with code
   - Update examples when APIs change
   - Maintain correct version information

3. **Documentation Review**:
   - Ensure accuracy and completeness
   - Check for broken links
   - Verify code examples work
   - Test documentation builds

4. **Automated Checks**:
   ```bash
   # Check links
   mkdocs build --strict
   
   # Build Sphinx docs
   sphinx-build -W -b html docs/ docs/_build/html
   ```

## Best Practices

1. **Keep Documentation Close to Code**:
   - Use detailed docstrings
   - Include usage examples
   - Document exceptions and edge cases

2. **Regular Updates**:
   - Review documentation monthly
   - Update for new features
   - Remove obsolete content
   - Check external links

3. **Use Documentation Tools**:
   - Automate API documentation
   - Generate diagrams from code
   - Maintain consistent formatting
   - Enable search functionality 