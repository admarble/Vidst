Development Guide
=================

This section contains information for developers working on the Video Understanding AI project.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   contributing
   ci-cd
   code-style
   testing
