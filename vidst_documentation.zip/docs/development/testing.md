# Testing Guide

This guide covers testing practices, tools, and guidelines for the Vidst project.

## Testing Setup

### Prerequisites
- Python 3.10+
- pytest
- pytest-cov
- pytest-mock
- pytest-asyncio

### Installation

```bash
pip install -r requirements-dev.txt
```

## Running Tests

### Basic Test Execution
```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_video_processor.py

# Run specific test class
pytest tests/test_video_processor.py::TestVideoProcessor

# Run specific test method
pytest tests/test_video_processor.py::TestVideoProcessor::test_scene_detection
```

### Test Coverage
```bash
# Generate coverage report
pytest --cov=src tests/

# Generate HTML coverage report
pytest --cov=src --cov-report=html tests/
```

## Writing Tests

### Test Structure
```python
class TestVideoProcessor:
    def setup_method(self):
        self.processor = VideoProcessor()
        self.test_file = "tests/fixtures/sample_video.mp4"
    
    def test_scene_detection(self):
        result = self.processor.detect_scenes(self.test_file)
        assert len(result["scenes"]) > 0
        assert all(isinstance(scene["start_time"], float) for scene in result["scenes"])
```

### Test Categories
1. Unit Tests (`tests/unit/`)
   - Test individual components
   - Mock external dependencies
   - Fast execution

2. Integration Tests (`tests/integration/`)
   - Test component interactions
   - Limited mocking
   - Real I/O operations

3. End-to-End Tests (`tests/e2e/`)
   - Test complete workflows
   - No mocking
   - Real external services

## Best Practices

1. Test Isolation
   - Each test should be independent
   - Clean up resources after tests
   - Use fixtures for common setup

2. Meaningful Assertions
   - Test expected outcomes
   - Include error cases
   - Verify edge cases

3. Test Documentation
   - Clear test names
   - Docstrings explaining test purpose
   - Comments for complex logic

## Coverage Requirements

- Minimum coverage: 90%
- Critical paths: 100%
- New features: 95%

## Handling Coverage Files

### Coverage Files
- `coverage.xml`: XML coverage report
- `coverage.svg`: Coverage badge
- `coverage_html/`: HTML coverage report

### Pre-commit Hooks
Pre-commit hooks run tests and update coverage files. Two options for handling commits:

1. Using `--no-verify` (when coverage requirements are met):
   ```bash
   git commit -m "feat: add feature" --no-verify
   ```

2. Staging coverage files separately:
   ```bash
   git add coverage.xml coverage.svg
   git commit -m "chore: update coverage"
   ```

## CI/CD Integration

Tests are automatically run in CI/CD pipeline:
1. On pull requests
2. On merge to main
3. Nightly builds

### CI/CD Test Configuration
```yaml
test:
  script:
    - pip install -r requirements-dev.txt
    - pytest --cov=src --cov-report=xml tests/
  artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura
        path: coverage.xml
```

## Documentation Tools

### Sphinx Documentation
Generate API documentation from docstrings:
```bash
cd docs
make api
make html
```

### MkDocs with Material Theme
Create modern documentation website:
```bash
# Serve documentation locally
mkdocs serve

# Build documentation
mkdocs build
```

### PDocs for Quick API Documentation
Generate quick API documentation:
```bash
pdoc --html src/
```

## Documentation Standards

1. Docstring Format
   - Use Google style
   - Include type hints
   - Document exceptions

2. Types of Documentation
   - API reference (auto-generated)
   - User guides (hand-written)
   - Tutorials (hand-written)

3. Markdown Guidelines
   - Use headers properly
   - Include code examples
   - Add cross-references

## Contributing to Documentation

1. Adding New Documentation
   - Create in appropriate section
   - Follow style guide
   - Include examples

2. Updating Documentation
   - Keep in sync with code
   - Update all affected docs
   - Verify links work

3. Documentation Review
   - Technical accuracy
   - Completeness
   - Clear writing

## Best Practices

1. Keep documentation close to code
2. Update docs with code changes
3. Regular documentation reviews
4. Use documentation tools effectively 