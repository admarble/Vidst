AI Models Module
==============

.. automodule:: src.ai.models
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The AI models module contains implementations of various AI models used in the system.

Models
------

GPT4VisionModel
~~~~~~~~~~~~~

.. autoclass:: src.ai.models.GPT4VisionModel
   :members:
   :undoc-members:
   :show-inheritance:

GeminiProVisionModel
~~~~~~~~~~~~~~~~~~

.. autoclass:: src.ai.models.GeminiProVisionModel
   :members:
   :undoc-members:
   :show-inheritance:

TwelveLabsModel
~~~~~~~~~~~~~

.. autoclass:: src.ai.models.TwelveLabsModel
   :members:
   :undoc-members:
   :show-inheritance:

WhisperModel
~~~~~~~~~~~

.. autoclass:: src.ai.models.WhisperModel
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.ai.models.load_model
.. autofunction:: src.ai.models.get_model_config
.. autofunction:: src.ai.models.initialize_models
