AI Pipeline Module
================

.. automodule:: src.ai.pipeline
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The AI pipeline module orchestrates the execution of AI models in the video processing pipeline.

Classes
-------

VideoPipeline
~~~~~~~~~~~

.. autoclass:: src.ai.pipeline.VideoPipeline
   :members:
   :undoc-members:
   :show-inheritance:

ModelPipeline
~~~~~~~~~~~

.. autoclass:: src.ai.pipeline.ModelPipeline
   :members:
   :undoc-members:
   :show-inheritance:

PipelineStage
~~~~~~~~~~~~

.. autoclass:: src.ai.pipeline.PipelineStage
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.ai.pipeline.create_pipeline
.. autofunction:: src.ai.pipeline.execute_pipeline
.. autofunction:: src.ai.pipeline.validate_pipeline
