Output Module
=============

.. automodule:: src.core.output
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The output module handles result formatting and output generation for the Video Understanding AI system.

Classes
-------

VideoOutput
~~~~~~~~~~

.. autoclass:: src.core.output.VideoOutput
   :members:
   :undoc-members:
   :show-inheritance:

ProcessingResult
~~~~~~~~~~~~~~

.. autoclass:: src.core.output.ProcessingResult
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.core.output.format_results
.. autofunction:: src.core.output.generate_report
.. autofunction:: src.core.output.export_results
