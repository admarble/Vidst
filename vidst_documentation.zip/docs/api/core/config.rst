Configuration Module
===================

.. automodule:: src.core.config
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The configuration module handles system-wide settings and configuration management.

Classes
-------

VideoConfig
~~~~~~~~~~

.. autoclass:: src.core.config.VideoConfig
   :members:
   :undoc-members:
   :show-inheritance:

ProcessingConfig
~~~~~~~~~~~~~~

.. autoclass:: src.core.config.ProcessingConfig
   :members:
   :undoc-members:
   :show-inheritance:

StorageConfig
~~~~~~~~~~~~

.. autoclass:: src.core.config.StorageConfig
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.core.config.load_config
.. autofunction:: src.core.config.validate_config
.. autofunction:: src.core.config.get_default_config
