Exceptions Module
================

.. automodule:: src.core.exceptions
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The exceptions module defines custom exceptions used throughout the Video Understanding AI system.

Exceptions
----------

VideoProcessingError
~~~~~~~~~~~~~~~~~~

.. autoexception:: src.core.exceptions.VideoProcessingError
   :members:
   :show-inheritance:

FileValidationError
~~~~~~~~~~~~~~~~~

.. autoexception:: src.core.exceptions.FileValidationError
   :members:
   :show-inheritance:

ProcessingError
~~~~~~~~~~~~~

.. autoexception:: src.core.exceptions.ProcessingError
   :members:
   :show-inheritance:

StorageError
~~~~~~~~~~~

.. autoexception:: src.core.exceptions.StorageError
   :members:
   :show-inheritance:

ModelError
~~~~~~~~~

.. autoexception:: src.core.exceptions.ModelError
   :members:
   :show-inheritance:

ConfigurationError
~~~~~~~~~~~~~~~~

.. autoexception:: src.core.exceptions.ConfigurationError
   :members:
   :show-inheritance:
