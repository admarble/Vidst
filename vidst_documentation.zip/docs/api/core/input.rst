Input Module
============

.. automodule:: src.core.input
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The input module handles all input processing and validation for the Video Understanding AI system.

Classes
-------

VideoInput
~~~~~~~~~

.. autoclass:: src.core.input.VideoInput
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.core.input.validate_video_file
.. autofunction:: src.core.input.check_video_format
.. autofunction:: src.core.input.get_video_metadata
