Cache Module
============

.. automodule:: src.storage.cache
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The cache module provides caching functionality for video processing results.

Classes
-------

Cache
~~~~~

.. autoclass:: src.storage.cache.Cache
   :members:
   :undoc-members:
   :show-inheritance:

CacheEntry
~~~~~~~~~

.. autoclass:: src.storage.cache.CacheEntry
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.storage.cache.initialize_cache
.. autofunction:: src.storage.cache.clear_cache
.. autofunction:: src.storage.cache.get_cache_stats
