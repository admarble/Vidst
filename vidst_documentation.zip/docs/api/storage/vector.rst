Vector Storage Module
==================

.. automodule:: src.storage.vector
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The vector storage module manages vector embeddings for video content.

Classes
-------

VectorStorage
~~~~~~~~~~~

.. autoclass:: src.storage.vector.VectorStorage
   :members:
   :undoc-members:
   :show-inheritance:

VectorIndex
~~~~~~~~~~

.. autoclass:: src.storage.vector.VectorIndex
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.storage.vector.create_index
.. autofunction:: src.storage.vector.search_vectors
.. autofunction:: src.storage.vector.optimize_index
