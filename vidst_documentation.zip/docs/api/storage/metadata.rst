Metadata Module
===============

.. automodule:: src.storage.metadata
   :members:
   :undoc-members:
   :show-inheritance:

Overview
--------

The metadata module manages metadata for video content and processing results.

Classes
-------

MetadataStore
~~~~~~~~~~~~

.. autoclass:: src.storage.metadata.MetadataStore
   :members:
   :undoc-members:
   :show-inheritance:

VideoMetadata
~~~~~~~~~~~

.. autoclass:: src.storage.metadata.VideoMetadata
   :members:
   :undoc-members:
   :show-inheritance:

Functions
---------

.. autofunction:: src.storage.metadata.store_metadata
.. autofunction:: src.storage.metadata.retrieve_metadata
.. autofunction:: src.storage.metadata.update_metadata
