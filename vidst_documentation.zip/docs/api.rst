API Reference
=============

This section provides detailed API documentation for all modules in the Video Understanding AI project.

Core Components
---------------

.. autosummary::
   :toctree: _autosummary
   :template: module.rst
   :recursive:

   src.core.test_doc
   src.core.input
   src.core.processing
   src.core.output
   src.core.exceptions
   src.core.config

AI Models
---------

.. autosummary::
   :toctree: _autosummary
   :template: module.rst
   :recursive:

   src.ai.models
   src.ai.pipeline

Storage
-------

.. autosummary::
   :toctree: _autosummary
   :template: module.rst
   :recursive:

   src.storage.cache
   src.storage.vector
   src.storage.metadata
