"""Sphinx configuration for Video Understanding AI documentation."""

import os
import sys
from datetime import datetime

# Add src directory to Python path
sys.path.insert(0, os.path.abspath(".."))
sys.path.insert(0, os.path.abspath("../src"))
sys.path.insert(0, os.path.abspath('_ext'))

# Project information
project = "Video Understanding AI"
copyright = f"{datetime.now().year}, Your Organization"
author = "Your Organization"

# The full version, including alpha/beta/rc tags
release = "0.1.0"

# Extensions
extensions = [
    "sphinx.ext.autodoc",  # Automatic API documentation
    "sphinx.ext.napoleon",  # Support for Google-style docstrings
    "sphinx.ext.viewcode",  # Add links to source code
    "sphinx.ext.githubpages",  # GitHub Pages support
    "sphinx_rtd_theme",  # Read The Docs theme
    "sphinx.ext.intersphinx",  # Link to other project's documentation
    "sphinx_autodoc_typehints",  # Better type hints support
    "myst_parser",  # Add support for Markdown
    "sphinx.ext.autosummary",  # Add autosummary support
    "accessibility"  # Our custom extension
]

# Autosummary settings
autosummary_generate = True
autosummary_imported_members = True
add_module_names = False

# Support both .rst and .md files
source_suffix = {
    '.rst': 'restructuredtext',
    '.md': 'markdown',
}

# Configure MyST-Parser for Markdown support
myst_enable_extensions = [
    'colon_fence',
    'deflist',
    'dollarmath',
    'fieldlist',
    'html_admonition',
    'html_image',
    'replacements',
    'smartquotes',
    'tasklist',
]

# Add any paths that contain templates
templates_path = ["_templates"]
html_static_path = ["_static"]

# List of patterns to exclude
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store", "_autosummary"]

# HTML theme settings
html_theme = "sphinx_rtd_theme"
html_theme_options = {
    "navigation_depth": 4,
    "titles_only": False,
    "logo_only": False,
    "display_version": True,
    "prev_next_buttons_location": "both",
    "style_external_links": True,
    "style_nav_header_background": "#2980B9",
    "collapse_navigation": False,
    "sticky_navigation": True,
    "includehidden": True,
}

# CSS/JS files - Update to use our custom CSS and JS
html_css_files = [
    "css/custom.css",
]

html_js_files = [
    "js/accessibility.js",
]

# Meta tags (single viewport) - Remove duplicate viewport
html_meta = {
    "description": "Video Understanding AI Documentation",
}

# Autodoc settings
autodoc_default_options = {
    "members": True,
    "undoc-members": True,
    "show-inheritance": True,
    "special-members": "__init__",
    "imported-members": True,
}

# Napoleon settings (Google-style docstrings)
napoleon_google_docstring = True
napoleon_numpy_docstring = False
napoleon_include_init_with_doc = True
napoleon_include_private_with_doc = False
napoleon_include_special_with_doc = True
napoleon_use_admonition_for_examples = True
napoleon_use_admonition_for_notes = True
napoleon_use_admonition_for_references = True
napoleon_use_ivar = True
napoleon_use_param = True
napoleon_use_rtype = True
napoleon_type_aliases = None

# Intersphinx mapping
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "numpy": ("https://numpy.org/doc/stable/", None),
    "opencv": ("https://docs.opencv.org/4.x/", None),
}

# Template customization
html_additional_pages = {}
html_secnumber_suffix = ". "  # Add period after section numbers
html_title_template = "%(title)s"  # Remove redundant title suffix
html_use_index = True
html_domain_indices = True
html_copy_source = False  # Don't include source files
html_show_sourcelink = False  # Don't show "Show Source" link

# Enable better code block highlighting
pygments_style = 'sphinx'
highlight_language = 'python3'

# Additional lexer settings
highlight_options = {
    'default_lang': 'python3',
    'guess_lang': False
}

# Accessibility configuration
html_show_sphinx = False  # Hide "Built with Sphinx" text
html_show_sourcelink = False  # Don't show "View page source"

# Custom HTML context
html_context = {
    'display_github': False,  # Hide GitHub link
    'show_sphinx': False,  # Hide Sphinx link
    'show_source': False,  # Hide source link
    'theme_display_version': False,  # Hide version
}

def setup(app):
    """Set up Sphinx application."""
    # Add our custom JavaScript
    app.add_js_file('js/accessibility.js')

    # Add our custom CSS
    app.add_css_file('css/custom.css')

    # Remove duplicate viewport meta tags
    app.connect('html-page-context', lambda app, pagename, templatename, context, doctree: context.update({
        'metatags': '\n'.join([
            '<meta charset="utf-8">',
            '<meta name="viewport" content="width=device-width, initial-scale=1.0">'
        ])
    }))

    return {
        'version': '1.0',
        'parallel_read_safe': True,
        'parallel_write_safe': True,
    }
