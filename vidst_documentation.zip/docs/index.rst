Welcome to Video Understanding AI Documentation
===============================================

This section provides detailed API documentation for all modules in the Video Understanding AI project.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   setup
   guides/index
   api
   development/index
   testing
   testing-guide
   issues-and-resolutions
   ci-cd
   README

Features
--------

- Scene detection and analysis
- Audio transcription with speaker identification
- Text extraction from video frames
- Natural language querying of video content
- Multi-modal AI model integration

Getting Started
---------------

Check out our :doc:`setup` guide to get started with the project.

API Documentation
-----------------

For detailed API documentation, see the :doc:`api` section.

Development
-----------

For development guidelines and best practices, see the :doc:`development/index` section.

Testing
-------

For information about testing, see the :doc:`testing` guide.

Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
