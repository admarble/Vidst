===================
Configuration Guide
===================

.. module:: src.core.config

.. index::
   single: configuration
   single: settings
   single: environment variables

Overview
--------

The Video Understanding AI system uses a flexible configuration system to manage settings for video processing, system resources, and API integrations. This guide explains how to effectively configure and customize the system for your needs.

.. _configuration_components:

Configuration Components
------------------------

The system's configuration is divided into several components:

1. Environment Variables
   - API keys
   - Environment-specific settings
   - Debug flags

2. Video Configuration
   - File size limits
   - Supported formats
   - Processing parameters

3. System Configuration
   - Resource limits
   - Concurrent processing
   - Memory management

.. _getting_started_with_config:

Getting Started
---------------

Basic Setup
~~~~~~~~~~~

1. Create a ``.env`` file in your project root:

   .. code-block:: bash

       # Required API Keys
       OPENAI_API_KEY=your_openai_key_here
       GEMINI_API_KEY=your_gemini_key_here
       TWELVE_LABS_API_KEY=your_twelve_labs_key_here

       # Environment Settings
       ENVIRONMENT=development
       DEBUG=true

       # Processing Settings
       UPLOAD_DIRECTORY=uploads
       MAX_CONCURRENT_JOBS=3
       CACHE_TTL=86400

2. Load configuration in your code:

   .. code-block:: python

       from src.core.config import load_config, VideoConfig

       # Load environment configuration
       env_config = load_config()

       # Initialize video configuration
       video_config = VideoConfig()
       video_config.validate()

.. _common_config_use_cases:

Common Use Cases
----------------

.. index::
   single: video configuration
   single: processing settings
   pair: configuration; video processing

Custom Video Processing Settings
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Customize video processing parameters:

.. code-block:: python

    from pathlib import Path
    from src.core.config import VideoConfig

    # Custom video configuration
    video_config = VideoConfig(
        upload_directory=Path("/custom/uploads"),
        supported_formats=["MP4", "MOV"],
        max_file_size=1024 * 1024 * 1024,  # 1GB
        min_scene_length=3,  # 3 seconds
        max_scenes_per_video=300
    )

    # Validate configuration
    video_config.validate()

.. _resource_management:

Resource Management
~~~~~~~~~~~~~~~~~~~

.. index::
   single: resource management
   pair: configuration; resources
   pair: configuration; memory limits

Configure system resource limits:

.. code-block:: python

    from src.core.config import ProcessingConfig

    # Custom processing configuration
    processing_config = ProcessingConfig(
        MAX_CONCURRENT_JOBS=5,
        MEMORY_LIMIT_PER_JOB=8 * 1024 * 1024 * 1024  # 8GB
    )

.. _environment_specific_config:

Environment-Specific Configuration
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. index::
   single: environment configuration
   pair: configuration; environment
   pair: configuration; production

Handle different environments:

.. code-block:: python

    def get_environment_config():
        config = load_config()
        
        if config['environment'] == 'production':
            return VideoConfig(
                max_file_size=5 * 1024 * 1024 * 1024,  # 5GB
                max_scenes_per_video=1000
            )
        else:
            return VideoConfig(
                max_file_size=1024 * 1024 * 1024,  # 1GB
                max_scenes_per_video=100
            )

.. _configuration_best_practices:

Best Practices
--------------

.. _environment_variables:

Environment Variables
~~~~~~~~~~~~~~~~~~~~~

.. index::
   single: environment variables
   pair: configuration; security
   pair: configuration; API keys

1. **Security**:

   .. code-block:: python

       import os
       from dotenv import load_dotenv

       def load_secure_config():
           # Load from environment first
           load_dotenv()
           
           # Validate API keys
           api_key = os.getenv('OPENAI_API_KEY')
           if not api_key:
               raise ConfigurationError(
                   "OpenAI API key not found. Please set OPENAI_API_KEY."
               )
               
           # Never log or expose API keys
           logger.info("API key loaded successfully")  # Good
           logger.debug(f"API key: {api_key}")  # Bad!

2. **Environment Files**:

   .. code-block:: bash

       # .env.example - Template for environment variables
       OPENAI_API_KEY=your_key_here
       ENVIRONMENT=development
       DEBUG=false

       # .gitignore
       .env
       .env.production

.. _configuration_validation:

Configuration Validation
~~~~~~~~~~~~~~~~~~~~~~~~

.. index::
   single: configuration validation
   pair: configuration; validation
   pair: configuration; error handling

Implement thorough validation:

.. code-block:: python

    class CustomVideoConfig(VideoConfig):
        def validate(self) -> None:
            # Call parent validation
            super().validate()
            
            # Custom validation
            if self.MAX_FILE_SIZE > 10 * 1024 * 1024 * 1024:  # 10GB
                raise ConfigurationError("File size limit exceeds 10GB")
                
            if len(self.SUPPORTED_FORMATS) > 5:
                raise ConfigurationError(
                    "Too many supported formats. Limit: 5"
                )

Error Handling
~~~~~~~~~~~~~~

Handle configuration errors gracefully:

.. code-block:: python

    from src.core.exceptions import ConfigurationError

    def initialize_system():
        try:
            # Load configuration
            config = load_config()
            
            # Initialize components
            video_config = VideoConfig()
            video_config.validate()
            
            return True
            
        except ConfigurationError as e:
            logger.error(f"Configuration error: {e}")
            
            if config.get('environment') == 'development':
                print_configuration_help()
            
            return False

Advanced Usage
--------------

Custom Configuration Classes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Create specialized configuration classes:

.. code-block:: python

    from dataclasses import dataclass
    from src.core.config import VideoConfig

    @dataclass
    class EducationalVideoConfig(VideoConfig):
        LECTURE_MAX_DURATION: int = 3600  # 1 hour
        SLIDE_DETECTION_ENABLED: bool = True
        OCR_ENABLED: bool = True
        
        def __post_init__(self):
            super().__init__()
            
            if self.LECTURE_MAX_DURATION > 7200:  # 2 hours
                raise ConfigurationError(
                    "Lecture duration cannot exceed 2 hours"
                )

Dynamic Configuration
~~~~~~~~~~~~~~~~~~~~~

Implement dynamic configuration updates:

.. code-block:: python

    class DynamicConfig:
        def __init__(self):
            self._config = load_config()
            self._last_update = time.time()
            
        def refresh(self):
            """Reload configuration if needed."""
            if time.time() - self._last_update > 300:  # 5 minutes
                self._config = load_config()
                self._last_update = time.time()
                
        def get(self, key: str) -> Any:
            self.refresh()
            return self._config.get(key)

Monitoring and Logging
----------------------

Implement configuration monitoring:

.. code-block:: python

    class ConfigurationMonitor:
        def __init__(self):
            self.logger = logging.getLogger('config')
            
        def log_configuration(self, config: Dict[str, Any]):
            """Log configuration safely (excluding sensitive data)."""
            safe_config = {
                k: v for k, v in config.items()
                if not k.endswith('_api_key')
            }
            
            self.logger.info(f"Current configuration: {safe_config}")
            
        def check_health(self, config: Dict[str, Any]) -> bool:
            """Check configuration health."""
            try:
                # Validate API keys
                validate_api_keys(config)
                
                # Check upload directory
                upload_dir = Path(config['upload_directory'])
                if not upload_dir.exists():
                    self.logger.error("Upload directory does not exist")
                    return False
                    
                # Check permissions
                if not os.access(upload_dir, os.W_OK):
                    self.logger.error("Upload directory not writable")
                    return False
                    
                return True
                
            except Exception as e:
                self.logger.error(f"Configuration health check failed: {e}")
                return False

Troubleshooting
---------------

Common Issues and Solutions
~~~~~~~~~~~~~~~~~~~~~~~~~~~

1. **Missing API Keys**:
   - Check ``.env`` file exists
   - Verify API key format
   - Ensure environment variables are loaded
   - Check for typos in variable names

2. **Permission Issues**:
   - Verify upload directory permissions
   - Check file ownership
   - Ensure proper user access

3. **Resource Limits**:
   - Monitor memory usage
   - Adjust concurrent job limits
   - Check disk space
   - Verify system capabilities

Additional Resources
--------------------

.. seealso::

   - :doc:`../api/\1` - Configuration API Reference
   - :doc:`../guides/\1` - Error Handling Guide
   - :doc:`../guides/\1` - Deployment Guide

.. note::
   For more information about environment-specific configuration, see :ref:`environment_specific_config`.

.. warning::
   Never commit sensitive information like API keys to version control. Always use environment variables or secure secrets management. 