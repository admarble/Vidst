# Quick Start Guide

This guide will help you get started with the Video Understanding AI project quickly.

## Installation

1. Clone the repository:
```bash
git clone https://github.com/your-org/video-understanding-poc
cd video-understanding-poc
```

2. Create and activate virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

## Basic Usage

```python
from video_understanding import VideoProcessor

# Initialize processor
processor = VideoProcessor()

# Process a video
result = processor.process("path/to/video.mp4")

# Query content
response = processor.query("What was discussed at 5:20?")
```

## Next Steps

For more detailed information, check out:

- [Configuration Guide](../guides/configuration.rst)
- [Video Processing Guide](../guides/video-processing.rst)
- [Error Handling Guide](../guides/error-handling.rst)
- [API Reference](../api/index.rst)
